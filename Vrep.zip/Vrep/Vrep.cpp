#include <iostream>
#include <stdio.h>
#include <tchar.h>

using namespace std;

extern "C" {
#include "extApi.h"
}

int _tmain(int argc, _TCHAR* argv[]) {
	int clientID = simxStart((simxChar*)"127.0.0.1", 19999, true, true, 2000, 5);

	if (clientID != -1)
	{
		simxAddStatusbarMessage(clientID, "Connected Completely!", simx_opmode_oneshot);
		cout << "Connection status to V REP : Success �������� ����" << endl;

	}
	else {
		cout << "Connection status to V REP : Falled" << endl;
		simxFinish(clientID);
		return clientID;
	}
	int right;
	simxGetObjectHandle(clientID, "hJoint", &right, simx_opmode_oneshot_wait);
	while (true)
	{
		simxSetJointTargetVelocity(clientID, right, 0.5, simx_opmode_streaming);
	}
	return 0;
}